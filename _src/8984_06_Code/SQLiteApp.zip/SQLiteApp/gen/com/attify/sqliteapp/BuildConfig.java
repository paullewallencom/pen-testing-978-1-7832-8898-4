/** Automatically generated file. DO NOT MODIFY */
package com.attify.sqliteapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}